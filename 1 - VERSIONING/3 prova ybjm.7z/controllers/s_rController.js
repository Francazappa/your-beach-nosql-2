const mongoose = require('mongoose');
const S_r = require('../models/S_r');

/**
 * 
 * metodi di izzi nel vecchio model (occhio, non controller)
 * 
 * async findCurrentReservations(lido){}
 * async findUserReservations(userId){}
 * 
 */

class s_rController {

    constructor(){}


    async getAllReservations(lido); // izzi
    async getUserReservation(lido, userID); // izzi
    async getSpecificDayReservations(lido, date);
    async getSpecificDayLocationReservation(lido, date, location); // location è la {row e la column} inviata dal front end che identifica l'ombrellone

}


module.exports = s_rController;