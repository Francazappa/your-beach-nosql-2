// hapi joi



// createNewLidoValidation


// updateLidoValidation