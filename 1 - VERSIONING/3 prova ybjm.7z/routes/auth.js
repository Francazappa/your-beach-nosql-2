const router = require('express').Router();
//const { registerValidation, loginValidation } = require('../functions/validation');
const Admin = require('../models/Admin');
const Owner = require('../models/Owner');
const Lido = require('../models/Lido');

const AdminController = require('../controllers/AdminController');
const admincontroller = new AdminController();

const OwnerController = require('../controllers/OwnerController');
const ownercontroller = new OwnerController();

const LidoController = require('../controllers/LidoController');
const lidocontroller = new LidoController();


// IMPLEMENTARE ASSOLUTAMENTE IL CONTROLLO DELLA SINTASSI PRIMA DI OGNI CHIAMATA AI METODI !!!!!!!!!!!!!
// IMPLEMENTARE ASSOLUTAMENTE IL CONTROLLO DELLA SINTASSI PRIMA DI OGNI CHIAMATA AI METODI !!!!!!!!!!!!!
// IMPLEMENTARE ASSOLUTAMENTE IL CONTROLLO DELLA SINTASSI PRIMA DI OGNI CHIAMATA AI METODI !!!!!!!!!!!!!
// IMPLEMENTARE ASSOLUTAMENTE IL CONTROLLO DELLA SINTASSI PRIMA DI OGNI CHIAMATA AI METODI !!!!!!!!!!!!!


// registrazione admin
router.post('/adminRegister', async (req, res) => {

    var result = await admincontroller.createNewAdmin(req.body);
    res.status(result[0]).json(result[1]);

});


// registrazione proprietario e lido
/**
 * 
 * req.body.owner contiene tutti i dati per la registrazione del proprietario
 * req.body.lido contiene tutti i dati per la registrazione di un nuovo lido
 * 
 * ha senso fare tutto con una chiamata nel backend? o è meglio 2 chiamate dal frontend?
 * 
 */
router.post('/ownerRegister', async (req, res) => {

    try{

        owner = await ownercontroller.createNewOwner(req.body.owner);
        res.status(owner[0]).json(owner[1]);

        lido = await lidocontroller.createNewLido(req.body.lido);
        res.status(lido[0]).json(lido[1]);

    }catch(err){

        res.status(500).json("SERVER ERROR: couldn\'t create register new owner and his lido");

    }

});


// login (sia per admin che per proprietario)
router.post('/adminOwnerLogin', async (req, res) => {

    // var result = await adminAuthController.login(req.body);
    res.status(result[0]).header('authToken', result[1]).json( { "token": result[1], "user": result[2] } );

});


router.post('/userLogin', async (req, res) => {

    // ahahah

});


module.exports = router;