const Admin = require('../models/Admin');
const Owner = require('../models/Owner');
const mongoose = require('mongoose');



class AdminAuthController {

    constructor(){}
    

    // DA DIVIDERE IN 2 PARTI !!!!
    async ownerRegister(data){

        /**
         * 
         * ownercontroller.createNewOwner(data)
         * lidocontroller.createNewLido(data)
         * 
         */
    
    }


    async adminRegister(data){

        
    
    }


    async adminOwnerLogin(data){



    }

}


module.exports = AdminAuthController;