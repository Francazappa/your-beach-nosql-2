const Lido = require('../models/Lido');


// ================================================================================================

// quando effettuo le varie chiamate get post odahdsfah uso questi due model per leggere e scrivere i dati
const Seat = require('../models/Seat');
const Reservation = require('../models/Reservation');

// questo model lo uso per tenere traccia di ciò che succede sopra tipo scontrino, è quindi passivo e lo pia ar culo
const S_r = require('../models/S_r');
// ================================================================================================


const mongoose = require('mongoose');


// si lo so che lidos è sbagliatissimo non rompete


class LidoController {

    constructor(){}


    // metodi di izzi che stavano nel model s_r =====================================================

    async findCurrentReservations(lido){

        // need some porting here

    }


    async findUserReservations(userId){

        // need some porting here

    }

    // ================================================================================================

}


module.exports = LidoController;