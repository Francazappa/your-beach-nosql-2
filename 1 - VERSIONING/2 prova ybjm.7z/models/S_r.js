const mongoose = require('mongoose');
const Reservation = require('./Reservation');
const Seat = require('./Seat');
const AutoIncrement = require('mongoose-sequence')(mongoose);

/*
l'incrocio dei seats e delle reservation avverrà nel controller in s_rController perché qui è evitabile.
questa entità serve solo per tenere traccia a livello formale a db delle prenotazioni di lettino xy in data x
buonasera popolo di striscia
*/

const s_rSchema = new mongoose.Schema({

    // inserire gli schemi degli altri model ??? | lo faccio o mi pento? | non lo voglio fare

    /*
    vechio codice:

    Seat.hasMany(Seat_Reservation);
    Reservation.hasMany(Seat_Reservation);
    Seat_Reservation.belongsTo(Seat);
    Seat_Reservation.belongsTo(Reservation);
    */

    // porco schifo è uno sballo mi piace

    reservationDate: {
        type: Reservation,
        required: true
    },

    seatLocation: {
        type: Seat,
        required: true
    }

    // f

});

s_rSchema.plugin(AutoIncrement,  {inc_field: 's_rID'});

// metodi (perché stanno qui, non dovrebbero stare nel controller?)

//findCurrentReservations(lido) ???
//findUserReservations(userId) ???

module.exports = mongoose.model('S_r', s_rSchema);